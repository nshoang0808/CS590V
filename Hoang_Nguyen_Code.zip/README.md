# This is a guide to run the visualization for given set data: Table 2A, Table 2J
# To preprocess data file, run $python Start.py
# To run the visualization in web browser, run in terminal: "npm run serve", then open web browser to http://localhost:8080/project.html